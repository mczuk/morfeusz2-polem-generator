/* 
 * File:   default_fsa.hpp
 * Author: mlenart
 *
 * Created on 21 październik 2013, 17:50
 */

#ifndef DEFAULT_FSA_HPP
#define	DEFAULT_FSA_HPP

namespace morfeusz {

extern const unsigned char DEFAULT_FSA[];
extern const unsigned char DEFAULT_SYNTH_FSA[];

}

#endif	/* DEFAULT_FSA_HPP */

